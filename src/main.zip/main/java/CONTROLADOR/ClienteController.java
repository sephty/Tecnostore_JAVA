/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import DAO.ClienteDAO;

/**
 *
 * @author garci
 */
public class ClienteController {
    ClienteDAO ClienteDAO = new ClienteDAO();
    
    public void insert (){
        
    }
}
