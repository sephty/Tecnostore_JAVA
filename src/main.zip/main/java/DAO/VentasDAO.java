
package DAO;

import CONTROLADOR.Conexion;
import MODELO.Celular;
import MODELO.Cliente;
import MODELO.ItemVenta;
import MODELO.Venta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;

public class VentasDAO {

    Conexion c = new Conexion();

    public boolean crear(Venta venta) {
        Connection con = null;
        try {
            con = c.conectar();
            con.setAutoCommit(false);

            String sqlVenta = "insert into ventas(id_cliente, fecha, total) values (?,?,?)";
            PreparedStatement psVenta = con.prepareStatement(sqlVenta, Statement.RETURN_GENERATED_KEYS);
            psVenta.setInt(1, venta.getCliente().getId());
            psVenta.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
            psVenta.setDouble(3, venta.getTotal());
            psVenta.executeUpdate();

            ResultSet keys = psVenta.getGeneratedKeys();
            int idVentaGenerada = 0;
            if (keys.next()) {
                idVentaGenerada = keys.getInt(1);
            }

            String sqlDetalle = "insert into detalle_ventas(id_venta, id_celular, cantidad, subtotal) values (?,?,?,?)";
            PreparedStatement psDetalle = con.prepareStatement(sqlDetalle);

            String sqlStock = "update celulares set stock = stock - ? where id = ?";
            PreparedStatement psStock = con.prepareStatement(sqlStock);

            ArrayList<ItemVenta> items = Venta.getDetalles();
            for (int i = 0; i < items.size(); i++) {
                ItemVenta item = items.get(i);

                psDetalle.setInt(1, idVentaGenerada);
                psDetalle.setInt(2, item.getCelular().getId());
                psDetalle.setInt(3, item.getCantidad());
                psDetalle.setDouble(4, item.getSubtotal());
                psDetalle.addBatch();

                psStock.setInt(1, item.getCantidad());
                psStock.setInt(2, item.getCelular().getId());
                psStock.addBatch();
            }
            psDetalle.executeBatch();
            psStock.executeBatch();

            con.commit();
            venta.setId(idVentaGenerada);
            System.out.println("Venta registrada correctamente!");
            return true;

        } catch (SQLException e) {
            try {
                if (con != null) {
                    con.rollback();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            System.out.println(e.getMessage());
            return false;
        } finally {
            try {
                if (con != null) {
                    con.setAutoCommit(true);
                    con.close();
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public ArrayList<Venta> listar() {
        ArrayList<Venta> respuesta = new ArrayList<>();
        try (Connection con = c.conectar()) {
            String sql = "select v.id, v.id_cliente, v.fecha, v.total, cl.nombre, cl.identificacion, cl.correo, cl.telefono "
                    + "from ventas v inner join clientes cl on v.id_cliente = cl.id";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Cliente cliente = new Cliente(rs.getInt(2), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8));
                respuesta.add(new Venta(rs.getInt(1), cliente, rs.getTimestamp(3), rs.getDouble(4)));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return respuesta;
    }

    public ArrayList<ItemVenta> listarDetalles(int idVenta) {
        ArrayList<ItemVenta> respuesta = new ArrayList<>();
        try (Connection con = c.conectar()) {
            String sql = "select dv.id, dv.id_venta, dv.cantidad, dv.subtotal, c.id, c.marca, c.modelo, c.sistema_operativo, c.gama, c.precio, c.stock "
                    + "from detalle_ventas dv inner join celulares c on dv.id_celular = c.id where dv.id_venta = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idVenta);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Celular celular = new Celular(rs.getInt(5), rs.getString(6), rs.getString(7), rs.getDouble(10), rs.getInt(11), rs.getString(8), rs.getString(9));
                respuesta.add(new ItemVenta(rs.getInt(1), rs.getInt(2), celular, rs.getInt(3), rs.getDouble(4)));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return respuesta;
    }

    public Venta buscar(int id) {
        Venta venta = null;
        try (Connection con = c.conectar()) {
            String sql = "select v.id, v.id_cliente, v.fecha, v.total, cl.nombre, cl.identificacion, cl.correo, cl.telefono "
                    + "from ventas v inner join clientes cl on v.id_cliente = cl.id where v.id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Cliente cliente = new Cliente(rs.getInt(2), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8));
                venta = new Venta(rs.getInt(1), cliente, rs.getTimestamp(3), rs.getDouble(4));
                venta.setDetalles(listarDetalles(id));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return venta;
    }

    public double totalVentasPorMes(int mes, int anio) {
        double total = 0;
        try (Connection con = c.conectar()) {
            String sql = "select sum(total) from ventas where month(fecha)=? and year(fecha)=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, mes);
            ps.setInt(2, anio);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                total = rs.getDouble(1);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return total;
    }
}
