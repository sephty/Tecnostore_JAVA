package CONTROLADOR;

import DAO.CelularDAO;

public class CelularController {

        CelularDAO CelularDAO = new CelularDAO();
    
        public void insert () {
            
        }
}
