/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

/**
 *
 * @author garci
 */
// MODELO/CategoriaGama.java

public enum CategoriaGama {
    ALTA, MEDIA, BAJA
}